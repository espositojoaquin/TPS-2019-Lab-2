﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Entidades;
using System.Collections.Generic;

namespace Test_Unitario
{
    [TestClass]
    public class UnitTest1
    {

        #region Test Lista instanciada
        /// <summary>
        /// verifica que la lista de Paquetes del correo este instanciada
        /// </summary>
        [TestMethod]
        public void listaInstanciada()
        {
            //Arrange 
            Correo correo = new Correo();
            List<Paquete> lista = null;
            //Act
            lista = correo.Paquetes;
            //Assert
            Assert.IsNotNull(lista);

        }

        #endregion

        
        #region Test Paquete Repetido
        /// <summary>
        /// Verifica que se lance la exepcion cuando se intenta agreagar un paquete que ya se encuentra dentro de la lista
        /// </summary>
        [TestMethod]
        public void PaquetesID()
        {

            //Arrange 
            Correo correo = new Correo();
            Paquete p1 = new Paquete("Padre Javier 588", "445-612-4562");
            Paquete p2 = new Paquete("Padre Javier 588", "445-612-4562");
            //Act
            try
            {
                correo += p1;
                correo += p2;
            }
            catch (Exception e)
            {
                //Assert
                Assert.IsInstanceOfType(e, typeof(TrackingIdRepetidoExeption));
            }

        } 
        #endregion

    }
}
