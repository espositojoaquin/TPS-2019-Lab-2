﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;


namespace Entidades
{
  public static  class PaqueteDAO
    {
        #region Delegado y evento
        /// <summary>
        /// Delegado para el evento Sql
        /// </summary>
        public delegate void DelegadoSql();
       
        
/// <summary>
        /// Evento que se lanzara en caso de producirse un error en la conecxion
        /// </summary>
        public static event DelegadoSql EventoSql;

        #endregion

        #region Atributos
        private static SqlConnection cn;
        private static SqlCommand command;

        #endregion

        #region Metodos
        /// <summary>
        /// Creo un objeto sqlConecction
        /// Creo un objeto SqlComand
        /// Inicio la conecxion
        /// </summary>
        static PaqueteDAO()
        {
            PaqueteDAO.cn = new SqlConnection(Properties.Settings.Default.MiBase);
            PaqueteDAO.command = new SqlCommand();
            PaqueteDAO.command.CommandType = System.Data.CommandType.Text;
            PaqueteDAO.command.Connection = PaqueteDAO.cn;
        }
        /// <summary>
        /// Inserta un Paquete a la base de datos
        /// </summary>
        /// <param name="pac"></param>
        /// <returns> true si se pudo caso contrario false y se lanza el evento</returns>
        public static bool Insertar(Paquete pac)
        {
            bool retorno = false;

            try
            {
                PaqueteDAO.command.CommandText = $"insert into Paquetes (direccionEntrega,trackingID,alumno) values ('{pac.DireccionEntrega}','{pac.TrackingID}','Joaquin Esposito')";
                PaqueteDAO.cn.Open();
                PaqueteDAO.command.ExecuteNonQuery();
                PaqueteDAO.cn.Close();
                retorno = true;

            }
            catch (SqlException)
            {

                PaqueteDAO.EventoSql();

            }
            catch (Exception)
            {
                PaqueteDAO.EventoSql();
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                {
                    PaqueteDAO.cn.Close();
                }
            }

            return retorno;
        } 
        #endregion
    }
}
