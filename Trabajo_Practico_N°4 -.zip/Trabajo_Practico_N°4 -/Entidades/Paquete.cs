﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace Entidades
{
    public class Paquete :IMostrar<Paquete>
    {
        #region Delegado y eventos
        /// <summary>
        /// Delegado de Informar Estado
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public delegate void DelegadoEstado(object sender, EventArgs e);
        
        /// <summary>
        /// Evento a ejecutar para informar los estados en ese momento de los paquetes
        /// </summary>
        public event DelegadoEstado InformaEstado;
        #endregion

        #region Enumerado

        public enum EEstado
        {
            Ingresado,
            EnViaje,
            Entregado
        }
        #endregion

        #region Atributos
        private string direccionEntrega;
        private EEstado estado;
        private string trackingID;

        #endregion

        #region Propiedades
        /// <summary>
        /// propiedad que da accesibilidad para setear o obtener datos de Direccion entrega
        /// </summary>
        public string DireccionEntrega
        {
            get { return this.direccionEntrega; }
            set { this.direccionEntrega = value; }
        }
        /// <summary>
        /// propiedad que da accesibilidad para setear o obtener datos de TrackingID
        /// </summary>
        public string TrackingID
        {
            get { return this.trackingID; }
            set { this.trackingID = value; }
        }
        /// <summary>
        /// propiedad que da accesibilidad para setear o obtener datos de Estado
        /// </summary>
        public EEstado Estado
        {
            get { return this.estado; }
            set { this.estado = value; }
        }
        #endregion

        #region Constructores
        /// <summary>
        /// Constructor Parametrizado que se le pasa la direccion y el TrackinID para que luego sea seteado
        /// </summary>
        /// <param name="direccionEntrega"></param>
        /// <param name="trackingID"></param>
        public Paquete(string direccionEntrega, string trackingID)
        {
            this.DireccionEntrega = direccionEntrega;
            this.TrackingID = trackingID;
        }
        #endregion

        #region Metodos
        /// <summary>
        /// Expone los datos del Paquete
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return String.Format($"{this.trackingID} para {this.direccionEntrega}");
        }
        /// <summary>
        /// Expone los datos del paquete y su estado
        /// </summary>
        /// <param name="elementos"></param>
        /// <returns></returns>
        public string MostarDatos(IMostrar<Paquete> elementos)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat($"{((Paquete)elementos).ToString()} ");
            sb.AppendLine($"({((Paquete)elementos).Estado})");
            return sb.ToString();
        } 
        /// <summary>
        /// Va cambiando el estado de los paquetes cada 4 segundos y al finalizar lo inserta en la base de datos. 
        /// </summary>
        public void MockCicloDeVida()
        {
            do
            {
                Thread.Sleep(4000);
                if (this.Estado == EEstado.Ingresado)
                {
                    this.Estado = EEstado.EnViaje;
                }
                else
                {
                    if(this.Estado==EEstado.EnViaje)
                    {
                        this.Estado = EEstado.Entregado;
                    }

                }

                InformaEstado(this,new EventArgs());

            } while (this.Estado != EEstado.Entregado);

            PaqueteDAO.Insertar(this);
            
        }
        #endregion

        #region Operadores

        /// <summary>
        /// seran iguales si su TrackignID son iguales
        /// </summary>
        /// <param name="p1"></param>
        /// <param name="p2"></param>
        /// <returns> true si son iguales en caso contrario false </returns>
        public static bool operator ==(Paquete p1, Paquete p2)
        {
            bool retorno = false;

            if (p1.TrackingID == p2.TrackingID)
            {
                retorno = true;
            }
            return retorno;
        }
        /// <summary>
        /// seran distintos si no coinciden sus TrackingID
        /// </summary>
        /// <param name="p1"></param>
        /// <param name="p2"></param>
        /// <returns>true si son distrintos false si son iguales </returns>
        public static bool operator !=(Paquete p1, Paquete p2)
        {
            return !(p1 == p2);
        } 
        #endregion

    }

}
