﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace Entidades
{
    public class Correo:IMostrar<List<Paquete>>
    {
        #region Atributos
        private List<Thread> mockPaquetes;
        private List<Paquete> paquetes;
        #endregion

        #region Propiedades
        /// <summary>
        /// Propiedad de lectura / escritura.
        /// </summary>
        public List<Paquete> Paquetes
        {
            get { return this.paquetes; }
            set { this.paquetes = value; }
        }

        #endregion

        #region Constructores
        /// <summary>
        /// Constructor por defecto que inicializa las listas
        /// </summary>
        public Correo()
        {
            this.paquetes = new List<Paquete>();
            this.mockPaquetes = new List<Thread>();
        }
        #endregion

        #region Operadores
        /// <summary>
        /// Suma un paquete a la lista siempre y cuando este ya no se encuentre dentro de esta.
        /// </summary>
        /// <param name="c"></param>
        /// <param name="p"></param>
        /// <returns></returns> el objeto de correo.
        public static Correo operator +(Correo c, Paquete p)
        {
            bool flag = false;
            if (!Equals(c, null) && !Equals(p, null))
            {
                foreach (Paquete item in c.paquetes)
                {
                    if (item == p)
                    {
                        flag = true;
                    }
                }

                if (flag)
                {
                    throw new TrackingIdRepetidoExeption("El Paquete ya se encuentra en la Lista");
                }
                else
                {
                    c.paquetes.Add(p);
                    Thread hilo = new Thread(p.MockCicloDeVida);
                    c.mockPaquetes.Add(hilo);
                    hilo.Start();

                }
            }
            return c;
        }

        #endregion

        #region Metodos
        /// <summary>
        /// Muestra todos los elementos de la lista Paquetes
        /// </summary>
        /// <param name="elementos"></param>
        /// <returns></returns> un string con todos los datos

        public string MostarDatos(IMostrar<List<Paquete>> elementos)
        {

            StringBuilder sb = new StringBuilder();

            foreach (Paquete item in ((Correo)elementos).paquetes)
            {
                sb.AppendFormat($"{item.MostarDatos(item)}");

            }

            return sb.ToString();
        }

        /// <summary>
        /// Finaliza todos los hilos que se encuentran activos hasta el momento
        /// </summary>

        public void FinEntregas()
        {
            foreach (Thread item in this.mockPaquetes)
            {
                if (item.IsAlive)
                {
                    item.Abort();

                }
            }
        } 
        #endregion
    }
}
