﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades;

namespace MiCalculadora
{
    public partial class LaCalculadora : Form
    {
        public LaCalculadora()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

            lblResultado.Text = "";
            cmbOperador.Text = "";
            txtNum1.Text = "";
            txtNum2.Text = "";

        }
        /// <summary>
        /// Realiza las 4 operaciones basicas matematicas
        /// </summary>
        /// <param name="num1"></param>
        /// <param name="num2"></param>
        /// <param name="opeador"></param>
        /// <returns></returns> retorno el resultado en double segun la operacion que se haya realizado
        private double Operar(string num1, string num2, string opeador)
        {
            double resultado;
            Numero numero1 = new Numero(num1);
            Numero numero2 = new Numero(num2);
            resultado = Calculadora.Operar(numero1, numero2, opeador);

            return resultado;
        }

      
        /// <summary>
        /// Realiza la operacion solicitada por el usuario
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnOperar_Click(object sender, EventArgs e)
        {
            string num1 = txtNum1.Text;
            string num2 = txtNum2.Text;
            string operador = cmbOperador.Text;
            double aux;
        
            aux = this.Operar(num1, num2, operador);
            if(aux==double.MinValue)
            {
                MessageBox.Show("No se puede dividir por 0", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
                lblResultado.Text= "Syntaxis Error";
            }
            else
            {
          
            lblResultado.Text = Convert.ToString(aux); 
            }
            
        }
     
        /// <summary>
        /// Se encarga de Limpiar los text box y el Label
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        private void btnLimpiar_Click(object sender, EventArgs e)
        {

            lblResultado.Text = "";
            cmbOperador.Text = "";
            txtNum1.Text = "";
            txtNum2.Text = "";
        }

        /// <summary>
        /// convierte el numero decimal ingresado por el usuario a binario
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnBin_Click(object sender, EventArgs e)
        {
            Numero num = new Numero();
            string aux;
            double num1, num2;
            string Nb;
            double resultado;

            if (lblResultado.Text != "")
            {
                aux = lblResultado.Text;
                lblResultado.Text = num.DecimalBinario(aux);
            
            }
            else
            {
                if (txtNum1.Text != "0" && txtNum2.Text != "0")
                {
                        num1 = Convert.ToDouble(txtNum1.Text);
                        num2 = Convert.ToDouble(txtNum2.Text);
                        resultado = num1 + num2;
                        Nb = Convert.ToString(resultado);
                        aux = num.DecimalBinario(Nb);
                        lblResultado.Text =aux;
                   
                }
                else
                {
                    if (txtNum1.Text == "0")
                    {
                        aux = txtNum2.Text;
                        lblResultado.Text =  num.DecimalBinario(aux);
                    }
                    else
                    {
                        aux = txtNum1.Text;
                        lblResultado.Text =  num.DecimalBinario(aux);
                    }
                }


            }


        }
        /// <summary>
        /// convierte el numero binario ingresado por el usuario a Decimal
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnDes_Click(object sender, EventArgs e)
        {

            Numero num = new Numero();
            string aux;
            double num1, num2;
            string Nb;
            double resultado;

            if (lblResultado.Text != "")
            {
                aux = lblResultado.Text;
                lblResultado.Text = num.BinarioDecimal(aux);

            }
            else
            {
                if (txtNum1.Text != "0" && txtNum2.Text != "0")
                {
                    num1 = Convert.ToDouble(txtNum1.Text);
                    num2 = Convert.ToDouble(txtNum2.Text);
                    resultado = num1 + num2;
                    Nb = Convert.ToString(resultado);
                    aux = num.BinarioDecimal(Nb);
                    lblResultado.Text = aux;


                }
                else
                {
                    if (txtNum1.Text == "0")
                    {
                        aux = txtNum2.Text;
                        lblResultado.Text = num.BinarioDecimal(aux);
                    }
                    else
                    {
                        aux = txtNum1.Text;
                        lblResultado.Text = num.BinarioDecimal(aux);
                    }
                }


            }

        }
        /// <summary>
        /// Cierra la calculadora
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnCerar_Click(object sender, EventArgs e)
        {
            LaCalculadora.ActiveForm.Close();
        }
    }
}
