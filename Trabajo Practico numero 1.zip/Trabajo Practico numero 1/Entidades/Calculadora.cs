﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Calculadora
    {
        #region Metodos
        /// <summary>
        /// Se encarga de Validar el operador (caracter) ingresado por el usuario
        /// </summary>
        /// <param name="operador">Representa el caracter a validar</param>
        /// <returns>Devuelve un caracter (en formato string) si el caracter es Valido, sino, devuelve el caracter "+"</returns>

        private static string ValidarOperador(string operador)
        {
            string retorno;
            if (operador == "+" || operador == "-" || operador == "/" || operador == "*")
            {
                retorno = operador;
            }
            else
            {
                retorno = "+";
            }
            return retorno;
        }
        /// <summary>
        /// Realiza la operacion solicitada por el usuario (suma, resta, multiplicacion, division)
        /// </summary>
        /// <param name="num1"> Objeto de tipo Numero representa el primer numero a calcular</param>
        /// <param name="num2">Objeto de tipo Numero representa el segundo numero a calcular</param>
        /// <param name="operador">Es el caracter (en formato string) representa la operacion a realizar</param>
        /// <returns>Retorna un valor double como resultado</returns>
        public static double Operar(Numero num1, Numero num2, string operador)
        {
            double retorno;
            Numero aux = new Numero();
            operador = Calculadora.ValidarOperador(operador);

            switch (operador)
            {
                case "+":
                    retorno = num1 + num2;
                    break;
                case "-":
                    retorno = num1 - num2;
                    break;
                case "*":
                    retorno = num1 * num2;
                    break;
                case "/":
                    if (num2 + aux == 0)
                    {
                        retorno = double.MinValue;
                    }
                    else
                    {
                        retorno = num1 / num2;
                    }
                    break;
                default:
                    retorno = num1 + num2;
                    break;

            }
            return retorno;



        }
        #endregion

    }
}
