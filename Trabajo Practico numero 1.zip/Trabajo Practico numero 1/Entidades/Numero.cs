﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Numero
    {
        #region Atributos
        /// <summary>
        ///  Atributo de instancia de tipo double y ademas privado
        /// </summary>
        private double numero;
        #endregion

        #region Constructores
        /// <summary>
        /// Constructor setea el valor inicial en 0
        /// </summary>
        public Numero()
        {
            this.numero = 0;
        }
        /// <summary>
        /// Constructor asigna valor ingresado por parametro
        /// </summary>
        /// <param name="numero">Double a asignar al objeto</param>
        public Numero(double num):this()
        {
            this.numero = num;
        }
        /// <summary>
        /// Constructor que setea el valor ingresado por parametro (string)
        /// </summary>
        /// <param name="numero">String a asignar al objeto</param>
        public Numero(string num):this()
        {
            this.SetNumero = num;
        }
        #endregion

        #region Propiedades
        /// <summary>
        /// Setea el atributo numero del objeto 
        /// </summary>
        public string SetNumero
        {
            set
            {
                this.numero = ValidarNumero(value);
            }
        }
        #endregion

        #region Operadores

        /// <summary>
        /// se encarga de realizar la suma entre dos elemento del tipo Numero
        /// </summary>
        /// <param name="numero1"></param>
        /// <param name="numero2"></param>
        /// <returns> Retorna el numero con el nuevo valor
        public static double operator +(Numero numero1, Numero numero2)
        {
            double num;
            num = numero1.numero + numero2.numero;


            return num;
        }
        /// <summary>
        /// se encarga de realizar la resta entre dos elemento del tipo Numero
        /// </summary>
        /// <param name="numero1"></param>
        /// <param name="numero2"></param>
        /// <returns> Retorna el numero con el nuevo valor
        public static double operator -(Numero numero1, Numero numero2)
        {
            double num;
            num = numero1.numero - numero2.numero;


            return num;

        }
        /// <summary>
        /// se encarga de realizar la multiolicacion entre dos elemento del tipo Numero
        /// </summary>
        /// <param name="numero1"></param>
        /// <param name="numero2"></param>
        /// <returns> Retorna el numero con el nuevo valor
        public static double operator *(Numero numero1, Numero numero2)
        {
            double num;
            num = numero1.numero * numero2.numero;

            return num;

        }
        /// <summary>
        /// se encarga de realizar la division entre dos elemento del tipo Numero
        /// </summary>
        /// <param name="numero1"></param>
        /// <param name="numero2"></param>
        /// <returns> Retorna el numero con el nuevo valor
        public static double operator /(Numero numero1, Numero numero2)
        {
            double num;
            num = numero1.numero / numero2.numero;

            return num;

        }
        #endregion

        #region Metodos
        /// <summary>
        /// Valida si lo que se ingreso es numerico
        /// </summary>
        /// <param name="numeroString">Cadena a validar</param>
        /// <returns>Devuelve el numero ingresado si es correcto, de lo contrario devuelve 0</returns>
        static double ValidarNumero(string numero)
        {
            double num;
            double retorno;

            if (double.TryParse(numero, out num))
            {
                retorno = num;
            }
            else
            {
                retorno = 0;
            }
            return retorno;


        }
        /// <summary>
        /// Convierte un numero de binario  a Decimal 
        /// </summary>
        /// <param name="bin"></param> el numero binario se toma en forma de string
        /// <returns></returns> retorna el numero decimal en forma de string

        public string BinarioDecimal(string bin)
        {
            int x, y;
            double num = 0;
            string retorno = "";
            bool verif = true;
            y = 0;

            for (x = bin.Length - 1; x >= 0; x--)
            {
                y++;
                if (bin[x] == '0' || bin[x] == '1')
                {
                    num += (double)(double.Parse(bin[x].ToString()) * Math.Pow(2, y));
                }
                else
                {
                    retorno = "No es binario";
                    verif = false;
                }

            }
            if (verif)
            {
                retorno = Convert.ToString(num / 2);

            }
            return retorno;
        }
        /// <summary>
        /// Convierte un numero decimal en Binario
        /// </summary>
        /// <param name="deci"></param> EL numero decimal se toma en forma de string
        /// <returns></returns>Devuelve el numero convertido a binario en forma de string
        public string DecimalBinario(string deci)
        {
            bool verif;
            string bin = "";
            int n;
            verif = int.TryParse(deci, out n);
            if (verif && n > -1)
            {

                while (true)
                {
                    if ((n % 2) != 0)
                    {
                        bin = "1" + bin;
                    }
                    else
                    {
                        bin = "0" + bin;
                    }
                    n /= 2;
                    if (n <= 0)
                    {
                        break;
                    }

                }

            }
            else
            {
                bin = "Valor invalido";
            }
            return bin;

        }
        /// <summary>
        /// Convierte un numero decimal en Binario
        /// </summary>
        /// <param name="deci"></param> EL numero decimal a convertir en forma de double
        /// <returns></returns>Devuelve el numero convertido a binario en forma de string
        public string DecimalBinario(double deci)
        {
            return DecimalBinario(Convert.ToString(deci));

        }
        #endregion

    }
}
